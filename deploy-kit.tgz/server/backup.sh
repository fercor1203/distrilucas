#!/usr/bin/env bash
# Copia consistente de la base de datos. Uso: bash backup.sh   (se programa a diario en el servidor)
set -euo pipefail
R="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$R/backups"
F="$R/backups/inventario-$(date +%F).db"
node -e "const {DatabaseSync}=require('node:sqlite');const d=new DatabaseSync('$R/database/inventario.db');d.exec(\"VACUUM INTO '$F'\")" 2>/dev/null || cp "$R/database/inventario.db" "$F"
find "$R/backups" -name 'inventario-*.db' -mtime +30 -delete
