// Servidor del Sistema de Inventario: API JSON + SQLite (sin dependencias, Node 22+)
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const PORT = +process.env.PORT || 3000;
const ROOT = path.resolve(__dirname, '..');
const DB_DIR = process.env.DB_DIR || path.join(ROOT, 'database');
const SITE = process.env.SITE_DIR || path.join(ROOT, 'site');
const COLS = ['categorias','productos','proveedores','clientes','compras','ventas','movimientos','cierres','suspendidas','usuarios','roles','tasas','abonos','config'];

fs.mkdirSync(DB_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DB_DIR, 'inventario.db'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;');
db.exec(`CREATE TABLE IF NOT EXISTS docs(
  col TEXT NOT NULL, id TEXT NOT NULL, data TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY(col,id))`);

const qAll = db.prepare('SELECT col,id,data FROM docs');
const qPut = db.prepare(`INSERT INTO docs(col,id,data,updated_at) VALUES(?,?,?,datetime('now'))
  ON CONFLICT(col,id) DO UPDATE SET data=excluded.data, updated_at=excluded.updated_at`);
const qDel = db.prepare('DELETE FROM docs WHERE col=? AND id=?');

function all() {
  const out = {}; COLS.forEach(c => out[c] = c === 'config' ? {} : []);
  for (const r of qAll.all()) {
    if (!out[r.col]) continue;
    const d = JSON.parse(r.data);
    if (r.col === 'config') { if (r.id === 'general') out.config = d; } else out[r.col].push(d);
  }
  return out;
}
function body(req) {
  return new Promise((ok, no) => {
    let b = ''; req.on('data', c => { b += c; if (b.length > 50e6) { no(new Error('grande')); req.destroy() } });
    req.on('end', () => { try { ok(b ? JSON.parse(b) : null) } catch (e) { no(e) } });
  });
}
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)) };

http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://x');
    const parts = u.pathname.split('/').filter(Boolean).map(decodeURIComponent);
    if (parts[0] !== 'api') { // archivos estáticos (en producción los sirve nginx; esto permite probar sin nginx)
      const f = path.join(SITE, u.pathname === '/' ? 'index.html' : path.normalize(u.pathname).replace(/^(\.\.[\/\\])+/, ''));
      if (!f.startsWith(SITE) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('no encontrado') }
      const t = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml' }[path.extname(f)] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': t }); return fs.createReadStream(f).pipe(res);
    }
    if (req.method === 'GET' && parts[1] === 'all') return send(res, 200, all());
    if (req.method === 'GET' && parts[1] === 'salud') return send(res, 200, { ok: true });
    if (req.method === 'POST' && parts[1] === 'import') {
      const d = await body(req);
      db.exec('BEGIN');
      try {
        for (const c of COLS) {
          if (c === 'config') { if (d.config && Object.keys(d.config).length) qPut.run('config', 'general', JSON.stringify(d.config)); continue }
          for (const x of d[c] || []) if (x && x.id) qPut.run(c, String(x.id), JSON.stringify(x));
        }
        db.exec('COMMIT');
      } catch (e) { db.exec('ROLLBACK'); throw e }
      return send(res, 200, { ok: true });
    }
    const [, col, id] = parts;
    if (!COLS.includes(col) || !id) return send(res, 400, { error: 'colección inválida' });
    if (req.method === 'PUT') {
      const d = await body(req);
      if (!d || typeof d !== 'object') return send(res, 400, { error: 'datos inválidos' });
      if (col !== 'config') d.id = id;
      qPut.run(col, id, JSON.stringify(d));
      return send(res, 200, { ok: true });
    }
    if (req.method === 'DELETE') { qDel.run(col, id); return send(res, 200, { ok: true }) }
    send(res, 405, { error: 'método no permitido' });
  } catch (e) { console.error(e); send(res, 500, { error: 'error del servidor' }) }
}).listen(PORT, '127.0.0.1', () => console.log('Inventario API en 127.0.0.1:' + PORT + ' · BD: ' + DB_DIR));
